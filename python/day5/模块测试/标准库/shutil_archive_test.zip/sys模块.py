# Author: Jason Lu

import sys
print(sys.version)

print(sys.maxsize)

print(sys.argv)